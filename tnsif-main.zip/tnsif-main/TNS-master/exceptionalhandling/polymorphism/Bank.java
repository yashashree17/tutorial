
public class Bank {
	public float getRateOfInterest() {
		return 6.7f;
	}
}
